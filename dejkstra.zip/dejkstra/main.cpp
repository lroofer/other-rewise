#include <iostream>
#include <vector>
#include <queue>

using namespace std;

int main() {
    int n;
    cin >> n;

    vector<vector<int>> g(n+1, vector<int>(n+1, 0));
    for(int i = 0; i < n; ++i){
        int a, b, d;
        cin >> a >> b >> d;
        g[a][b] = g[b][a] = d;
    }
    vector<int> visited(n+1);
    vector<int> dist(n+1, INT_MAX);
    dist[0] = 0;
    visited[0] = 1;
    queue<int> q;
    q.push(0);
    while(!q.empty()){
        int vertex = q.front();
        q.pop();
        for(int j = 1; j < g[vertex].size(); j++){
            if (!visited[j] && g[vertex][j] && g[vertex][j] + dist[vertex] < dist[j]){
                dist[j] = g[vertex][j] + dist[vertex];
                q.push(j);
            }

        }
    }
    return 0;
}
